# Lokaverkefni
Hópavinnu verkefni á tölvubraut
